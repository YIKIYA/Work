package com.school.backend_school.service;

import com.school.backend_school.domain.User;
import com.school.backend_school.mapper.UserMapper;
import com.school.backend_school.service.Impl.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService implements UserServiceImpl {

    @Autowired
    private UserMapper userMapper;

    @Override
    public List<User> findAll() {
        return userMapper.getSelect();
    }

    @Override
    public int count() {
        return userMapper.total();
    }

    @Override
    public void save(User user) {
        userMapper.insert(user);
    }

    @Override
    public void delete(int id) {
        userMapper.delete(id);
    }

    @Override
    public void update(User user) {
        userMapper.update(user);
    }

    @Override
    public User findById(int id) {
        return userMapper.getSelectById(id);
    }

    @Override
    public boolean login(String username, String password) {
        if (userMapper.login(username,password)!=0) {
            return true;
        }
        return false;
    }
}
