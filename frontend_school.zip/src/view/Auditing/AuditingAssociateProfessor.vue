<template>
  <el-container>
    <el-header >
      <el-input v-model="input" placeholder="输入名字查找信息" maxlength="15" show-word-limit class="lookname"></el-input>
      <el-button type="primary" icon="el-icon-search" plain @click="lookInformation(input)">搜索</el-button>
    </el-header>
    <div>
    <el-table :data="tableData" style="width: 100%">
      <el-table-column label="用户ID" width="180">
        <template slot-scope="scope">
          <span style="margin-left: 10px">{{ scope.row.userId }}</span>
        </template>
      </el-table-column>
      <el-table-column label="姓名" width="180">
        <template slot-scope="scope">
          <span style="margin-left: 10px">{{ scope.row.name }}</span>
        </template>
      </el-table-column>
      <el-table-column label="评审专家" width="180">
        <template slot-scope="scope">
          <span style="margin-left: 10px">{{ scope.row.expert }}</span>
        </template>
      </el-table-column>
      <el-table-column label="申报职位" width="180">
        <template slot-scope="scope">
          <span style="margin-left: 10px">{{ scope.row.specialty }}</span>
        </template>
      </el-table-column>
      <el-table-column label="表决结果" width="180">
        <template slot-scope="scope">
          <span style="margin-left: 10px">{{ scope.row.secondAuditing }}</span>
        </template>
      </el-table-column>
      <el-table-column label="查看资料">
        <template slot-scope="scope">
          <el-link @click="handlook(scope.row.userId)">{{scope.row.name}}申请资料<i class="el-icon-view el-icon--right"></i> </el-link>
          <!-- <el-button size="mini" @click="handlook(scope.row.userId)">查看资料</el-button> -->
        </template>
      </el-table-column>
      <el-table-column label="表决">
        <template slot-scope="scope">
          <el-button size="mini" @click="handleYes(scope.row.userId)">通过</el-button>
          <el-button size="mini" type="danger" @click="handleNo(scope.row.userId)">不通过</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
  <!-- 分页 -->
  <div class="pag">
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="limitPage.page"
        :page-sizes="[5, 10, 15, 20]"
        :page-size="limitPage.limit"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total">
      </el-pagination>
  </div>
  <!-- 弹出框 -->
  <template>
    <el-dialog title="提示" :visible.sync="dialogVisible" width="90%">
          <div class="print" ref="print">
      <div style="margin:0 auto;">
        <!-- //标题盒子 -->
        <div
          style="font-size:30px; color: black; text-align:center;margin-top:0px; margin-bottom: 20px;"
        >
          高等学校教师系列高级专业技术职务申报人员情况公示表
        </div>

        <div style="font-size:20px; color: black; text-align:right; margin: 20px;display:flex;justify-content:space-between">
          <span >单位：</span>
          <span v-show="isEdit"> <input type="text" v-model="information.company"> </span>
          <span v-show="!isEdit">{{information.company}}</span>
          <span >姓名：</span>
          <span v-show="isEdit"> <input type="text" v-model="information.name"> </span>
          <span v-show="!isEdit">{{information.name}}</span>
          <span >申报职务：</span>
          <span v-show="isEdit"> <input type="text" v-model="information.jobDeclaration"> </span>
          <span v-show="!isEdit">{{information.jobDeclaration}}</span>
          <span >学科（专业）：</span>
          <span v-show="isEdit"> <input type="text" v-model="information.major"> </span>
          <span v-show="!isEdit">{{information.major}}</span>

        </div>
        <table
          style="width: 100%"
          class="table table-striped table-bordered"
          align="left"
          valign="center"
        >
            <!-- 基本信息 任职以来主要业绩 -->
          <tr>
            <td class="column" colspan="10">基本信息</td>
            <td class="column" colspan="22">任现职以来主要业绩</td>
          </tr>
          <!-- 基本信息 -->
          <tr>
            <td class="column" colspan="2">姓名</td>
            <td class="value" colspan="2" v-show="isEdit"> <input type="text" v-model="information.name"> </td>
            <td class="value" colspan="2" v-show="!isEdit">{{information.name}}</td>
            <td class="column" colspan="4">出生年月</td>
            <td class="value" colspan="2" v-show="isEdit" ><input type="text" v-model="information.birthDate"> </td>
            <td class="value" colspan="2" v-show="!isEdit">{{information.birthDate}}</td>
            <td colspan="1" rowspan="8" class="column">教学工作</td>
            <td colspan="11" class="column">教学工作量（其他教学工作量按本校教学工作量计算）</td>
            <td colspan="4" class="column">主要教学业绩</td>
            <td colspan="4" class="column">指导青年教师情况</td>
            <td colspan="2" rowspan="8" class="column">教务部门审核意见（盖章）：</td>
          </tr>
          <tr>
            <td class="column" colspan="2">性别</td>
            <td class="value" colspan="2" v-show="isEdit"><input type="text" v-model="information.sex"></td>
            <td class="value" colspan="2" v-show="!isEdit">{{information.sex}}</td>
            <td class="column" colspan="4">参加工作时间</td>
            <td class="value" colspan="2" v-show="isEdit"><input type="text" v-model="information.workDate"></td>
            <td class="value" colspan="2" v-show="!isEdit">{{information.workDate}}</td>
            <td colspan="2" rowspan="7" class="column">按年度填写教学工作量</td>
            <td colspan="2" rowspan="2" class="column">年度</td>
            <td colspan="4" class="column">课堂教学（学时）</td>
            <td colspan="3" rowspan="2" class="column">其他教学工作量</td>
            <td colspan="4" class="value" rowspan="4" v-show="isEdit"><textarea cols="auto" rows="10" v-model="information.mostTeach"></textarea></td>
            <td colspan="4" class="value" rowspan="4" v-show="!isEdit">{{information.mostTeach}}</td>
            <td colspan="4" class="value" rowspan="4" v-show="isEdit"><textarea cols="auto" rows="10" v-model="information.teachTeacher"></textarea></td>
            <td colspan="4" class="value" rowspan="4" v-show="!isEdit">{{information.teachTeacher}}</td>
          </tr>
          <tr>
            <td class="column" colspan="4">现任技术职务</td>
            <td class="value" colspan="2" v-show="isEdit"><input type="text" v-model="information.job"></td>
            <td class="value" colspan="2" v-show="!isEdit">{{information.job}}</td>
            <td class="column" colspan="2">获得时间</td>
            <td class="value" colspan="2" v-show="isEdit"> <input type="text" v-model="information.jobTime"></td>
            <td class="value" colspan="2" v-show="!isEdit">{{information.jobTime}}</td>
            <td class="column" colspan="2">理论教学</td>
            <td class="column" colspan="2">实践教学</td>
          </tr>
          <tr>
            <td class="column" colspan="2">外语成绩</td>
            <td class="value" colspan="2" v-show="isEdit"><input type="text" v-model="information.foreignLanguage"> </td>
            <td class="value" colspan="2" v-show="!isEdit">{{information.foreignLanguage}}</td>
            <td class="column" colspan="4">计算机成绩</td>
            <td class="value" colspan="2" v-show="isEdit"><input type="text" v-model="information.csLevel"> </td>
            <td class="value" colspan="2" v-show="!isEdit">{{information.csLevel}}</td>
            <td colspan="2" class="value" rowspan="5" v-show="isEdit"><input type="text" v-model="information.year"></td>
            <td colspan="2" class="value" rowspan="5" v-show="!isEdit">{{information.year}}</td>
            <td colspan="2" class="value" rowspan="5" v-show="isEdit"><input type="text" v-model="information.theoryTeach"></td>
            <td colspan="2" class="value" rowspan="5" v-show="!isEdit">{{information.theoryTeach}}</td>
            <td colspan="2" class="value" rowspan="5" v-show="isEdit"><input type="text" v-model="information.practicalTeach"></td>
            <td colspan="2" class="value" rowspan="5" v-show="!isEdit">{{information.practicalTeach}}</td>
            <td colspan="3" class="value" rowspan="5" v-show="isEdit"><input type="text" v-model="information.otherTeach"></td>
            <td colspan="3" class="value" rowspan="5" v-show="!isEdit">{{information.otherTeach}}</td>
          </tr>
          <tr>
            <td class="column" colspan="2">最高学历</td>
            <td class="value" colspan="2" v-show="isEdit"><input type="text" v-model="information.education"> </td>
            <td class="value" colspan="2" v-show="!isEdit">{{information.education}}</td>
            <td class="column" colspan="4">最高学位</td>
            <td class="value" colspan="2" v-show="isEdit"><input type="text" v-model="information.degree"> </td>
            <td class="value" colspan="2" v-show="!isEdit">{{information.degree}}</td>
          </tr>
          <tr>
            <td class="column" colspan="2">现从事专业</td>
            <td class="value" colspan="2" v-show="isEdit"><input type="text" v-model="information.workMajor"></td>
            <td class="value" colspan="2" v-show="!isEdit">{{information.workMajor}}</td>
            <td class="column" colspan="4">是否破格</td>
            <td class="value" colspan="2" v-show="isEdit"><input type="text" v-model="information.isException"></td>
            <td class="value" colspan="2" v-show="!isEdit">{{information.isException}}</td>
            <td colspan="8" class="column" >任课教程</td>
          </tr>
          <tr>
            <td class="column" colspan="8">毕业学校及专业</td>
            <td class="column" colspan="2">毕业时间</td>
            <td colspan="8" class="value" rowspan="2" v-show="isEdit"><input type="text" v-model="information.teachCourse"></td>
            <td colspan="8" class="value" rowspan="2" v-show="!isEdit">{{information.teachCourse}}</td>
          </tr>
          <tr>
            <td class="value" colspan="8" v-show="isEdit"><input type="text" v-model="information.schoolAndMajor"></td>
            <td class="value" colspan="8" v-show="!isEdit">{{information.schoolAndMajor}}</td>
            <td class="value" colspan="2" v-show="isEdit"><input type="text" v-model="information.dateOfGraduation"></td>
            <td class="value" colspan="2" v-show="!isEdit">{{information.dateOfGraduation}}</td>
          </tr>
          <!-- 考核情况 -->
          <tr>
            <td  class="column" colspan="10">近五年年度考核情况</td>
            <td colspan="1" rowspan="8" class="column">科研工作</td>

            <td colspan="2" rowspan="4" class="column">主要著作或论文（标题、刊物名称、发表时间、作者排名:代表作）</td>
            <td colspan="4" class="column">论文总数</td>
            <td colspan="2" rowspan="1" class="value" v-show="isEdit"><input type="text" v-model="information.papers"></td>
            <td colspan="2" rowspan="1" class="value" v-show="!isEdit">{{information.papers}}</td>
            <td colspan="9" class="column">专(译〉著﹑国家级规划教材﹑省级规划教材数</td>
            <td colspan="2" rowspan="1" class="value" v-show="isEdit"><input type="text" v-model="information.materials"></td>
            <td colspan="2" rowspan="1" class="value" v-show="!isEdit">{{information.materials}}</td>
            <td colspan="2" rowspan="8" class="column">科研部门审核意见(盖章): 科研部门审核人签名:</td>
          </tr>
          <tr>
            <td class="column" colspan="2" rowspan="1">年度</td>
            <td class="column" colspan="2" rowspan="1">年度</td>
            <td class="column" colspan="2" rowspan="1">年度</td>
            <td class="column" colspan="2" rowspan="1">年度</td>
            <td class="column" colspan="2" rowspan="1">年度</td>
            <td colspan="17" rowspan="2" class="value" v-show="isEdit"><textarea cols="80" rows="5" v-model="information.detailsOfpapers"></textarea></td>
            <td colspan="17" rowspan="2" class="value" v-show="!isEdit">{{information.detailsOfpapers}}</td>
          </tr>
          <tr>
            <td class="value" colspan="2" rowspan="1" v-show="isEdit"><input type="text" v-model="information.year1"></td>
            <td class="value" colspan="2" rowspan="1" v-show="!isEdit">{{information.year1}}</td>
            <td class="value" colspan="2" rowspan="1" v-show="isEdit"><input type="text" v-model="information.year2"></td>
            <td class="value" colspan="2" rowspan="1" v-show="!isEdit">{{information.year2}}</td>
            <td class="value" colspan="2" rowspan="1" v-show="isEdit"><input type="text" v-model="information.year3"></td>
            <td class="value" colspan="2" rowspan="1" v-show="!isEdit">{{information.year3}}</td>
            <td class="value" colspan="2" rowspan="1" v-show="isEdit"><input type="text" v-model="information.year4"></td>
            <td class="value" colspan="2" rowspan="1" v-show="!isEdit">{{information.year4}}</td>
            <td class="value" colspan="2" rowspan="1" v-show="isEdit"><input type="text" v-model="information.year5"></td>
            <td class="value" colspan="2" rowspan="1" v-show="!isEdit">{{information.year5}}</td>
          </tr>

          <!-- 左下审核框 -->
          <tr>
            <td rowspan="2" colspan="10" class="column">
              工作经历与现任职以来的继续教育情况
            </td>
            <td colspan="4" rowspan="1" class="column">主持研究项目数</td>
            <td colspan="1" rowspan="1" class="value" v-show="isEdit"><input type="text" v-model="information.projectNumber"></td>
            <td colspan="1" rowspan="1" class="value" v-show="!isEdit">{{information.projectNumber}}</td>
            <td colspan="4" rowspan="1" class="column">参与研究数</td>
            <td colspan="1" rowspan="1" class="value" v-show="isEdit"><input type="text" v-model="information.studies"></td>
            <td colspan="1" rowspan="1" class="value" v-show="!isEdit">{{information.studies}}</td>
            <td colspan="1" rowspan="1" class="column">科研经费</td>
            <td colspan="1" rowspan="1" class="value" v-show="isEdit"><input type="text" v-model="information.money"></td>
            <td colspan="1" rowspan="1" class="value" v-show="!isEdit">{{information.money}}</td>
            <td colspan="2" rowspan="1" class="column">技术开发或管理项目</td>
            <td colspan="1" rowspan="1" class="value" v-show="isEdit"><input type="text" v-model="information.managerProject"></td>
            <td colspan="1" rowspan="1" class="value" v-show="!isEdit">{{information.managerProject}}</td>
            <td colspan="1" rowspan="1" class="column">专利数</td>
            <td colspan="1" rowspan="1" class="value" v-show="isEdit"><input type="text" v-model="information.patent"></td>
            <td colspan="1" rowspan="1" class="value" v-show="!isEdit">{{information.patent}}</td>
          </tr>
          <!-- 换行 -->
          <tr>

          </tr>
          <tr>
            <td class="value" colspan="10" rowspan="3" v-show="!isEdit">
              {{information.workAndNowDetails}}
              <div class="leftFa">
                <div class="left1">审核人签名：</div>
                <div class="left2">人事部门盖章：</div>
              </div>
            </td>
            <td class="value" colspan="10" rowspan="3" v-show="isEdit">
              <textarea cols="30" rows="6" v-model="information.workAndNowDetails"></textarea>
              <div class="leftFa" v-show="!isEdit">
                <div class="left1">审核人签名：</div>
                <div class="left2">人事部门盖章：</div>
              </div>
            </td>
            <td colspan="2" rowspan="8" class="column">承担或参与的科研技术开发项目（项目名称、立项审批单位、项目编号及鉴定获奖情况）</td>
            <td colspan="17" rowspan="5" class="value" v-show="isEdit"><textarea cols="80" rows="6" v-model="information.detailsOfStudies" class="input_left"></textarea></td>
              <td colspan="17" rowspan="5" class="value" v-show="!isEdit">{{information.detailsOfStudies}}</td>
          </tr>
        </table>
        <br />
        <div style="line-height: 30px; color: #333333;">
          <div>*此记录基本信息栏为电子录入记录。</div>
          <div>注1.请保证数据的准确性</div>
          <div>&nbsp;&nbsp;&nbsp;2.时间格式为yyyy-mm-dd</div>
        </div>
        <br />
      </div>
    </div>
      <span slot="footer" class="dialog-footer">
        <el-button @click="dialogVisible = false">关闭</el-button>
      </span>
    </el-dialog>
  </template>
  </el-container>
</template>

<script>
import axios from 'axios'

export default {
  data () {
    return {
      isEdit: false,
      dialogVisible: false,
      input: null,
      tableData: [{
        userId: '1',
        name: '王小虎',
        expert: '评审专家',
        specialty: '副教授',
        secondAuditing: '通过',
        firstAuditing: '通过'
      },
      {
        userId: '2',
        name: '王小虎1',
        expert: '123',
        specialty: '副教授',
        secondAuditing: '通过',
        firstAuditing: '通过'
      }
      ],
      tableDataById: {},
      limitPage: {
        page: 1,
        limit: 5
      },
      total: 0,
      information: {}
    }
  },
  created () {
    this.showPage()
  },
  methods: {
    // 分页
    handleSizeChange (val) {
      this.limitPage.limit = val
      this.showPage()
    },
    handleCurrentChange (val) {
      this.limitPage.page = val
      this.showPage()
    },
    // 数据列表分页
    showPage () {
      axios.post(`/api/findByPage/${this.limitPage.page}/${this.limitPage.limit}/副教授`).then(res => {
        this.tableData = res.data
        this.conut()
      })
    },
    // 查找全部
    show () {
      axios.get('/api/findBySpecialty/副教授').then(res => {
        this.tableData = res.data
      })
    },
    // 保存
    save () {
      axios.put('/api/updateSecondAuditing', this.tableDataById).then(res => {
        //   setTimeout(() =>{
        //   this.show()
        // },1000)
        this.showPage()
      })
      this.$message({
        type: 'success',
        message: '成功'
      })
    },
    // 总数
    conut () {
      axios.get('/api/auditingCount/副教授').then(res => {
        this.total = res.data
      })
    },
    lookInformation (input) {
      if (input == null) {
        this.showPage()
      } else {
        axios.get(`/api/findByAuditingName/${input}`).then(res => {
          this.tableData = res.data
          this.total = 1
          this.input = null
        })
      }
    },
    handlook (id) {
      axios.get(`/api/findUserById/${id}`).then(res => {
        this.information = res.data
      })
      this.dialogVisible = true
    },
    handleYes (id) {
      axios.get(`/api/findByAuditingId/${id}`).then(res => {
        this.tableDataById = res.data
        this.tableDataById.expert = '王小虎'
        this.tableDataById.secondAuditing = '通过'
        // setTimeout(() =>{
        //   this.save()
        // },1000)
        this.save()
      })
    },
    handleNo (id) {
      axios.get(`/api/findByAuditingId/${id}`).then(res => {
        this.tableDataById = res.data
        this.tableDataById.expert = '王小虎'
        this.tableDataById.secondAuditing = '不通过'
        // setTimeout(() =>{
        //   this.save()
        // },1000)
        this.save()
      })
    }

  }
}
</script>

<style>
.lookname{
  width: 30%;
}
.pag{
  text-align: center;
}
.el-pagination{
  text-align: center;
}
input{
  width: 100%;
  height: 100%;
}
.input_left{
  text-align: left;
}
.button_group {
  margin-top: 30px;
  margin-right: 30px;
  display: flex;
  align-items: center;
  justify-content: flex-end;
}
.print {
  width: 90%;
  margin: 0 auto;
  max-width: 1280px;
}
.table {
  border-collapse: collapse;
  border-spacing: 0;
  background-color: transparent;
  display: table;
  width: 100%;
  max-width: 100%;
  width: 800px;
  margin: 0 auto;
}
.table td {
  text-align: center;
  width:30px;
  vertical-align: middle;
  font-size: 12px;
  font-family: "Arial Normal", "Arial";
  color: #333333;
  padding: 8px 12px;
}
.table-bordered {
  border: 1px solid #ddd;
}
.column {
  width: 30px;
  height: 30px;
  border: 1px solid #333;
  background: #f1f1f1;
}
.value {
  width: 70px;
  height: 30px;
  border: 1px solid #333;
}
.el-main {
    line-height: 10px;
    height: 900px;
}

.left1{
  position: relative;
  top: 20px;
}
.left2{
  position: relative;
  top: 30px;
}
</style>
