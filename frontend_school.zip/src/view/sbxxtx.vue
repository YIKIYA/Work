<template>
  <div class="my-multi-table">
    <div class="print" ref="print">
      <div style="margin:0 auto;">

        <!-- //标题盒子 -->
        <div
          style="font-size:30px; color: black; text-align:center;margin-top:0px; margin-bottom: 20px;"
        >
          高等学校教师系列高级专业技术职务申报人员情况公示表
        </div>

        <div style="font-size:20px; color: black; text-align:right; margin: 20px;display:flex;justify-content:space-between">
          <span >单位：</span>
          <span v-show="isEdit"> <input type="text" v-model="information.company"> </span>
          <span v-show="!isEdit">{{information.company}}</span>
          <span >姓名：</span>
          <span v-show="isEdit"> <input type="text" v-model="information.name"> </span>
          <span v-show="!isEdit">{{information.name}}</span>
          <span >申报职务：</span>
          <span v-show="isEdit"> <input type="text" v-model="information.jobDeclaration"> </span>
          <span v-show="!isEdit">{{information.jobDeclaration}}</span>
          <span >学科（专业）：</span>
          <span v-show="isEdit"> <input type="text" v-model="information.major"> </span>
          <span v-show="!isEdit">{{information.major}}</span>

        </div>
        <table
          style="width: 100%"
          class="table table-striped table-bordered"
          align="left"
          valign="center"
        >
            <!-- 基本信息 任职以来主要业绩 -->
          <tr>
            <td class="column" colspan="10">基本信息</td>
            <td class="column" colspan="22">任现职以来主要业绩</td>
          </tr>
          <!-- 基本信息 -->
          <tr>
            <td class="column" colspan="2">姓名</td>
            <td class="value" colspan="2" v-show="isEdit"> <input type="text" v-model="information.name"> </td>
            <td class="value" colspan="2" v-show="!isEdit">{{information.name}}</td>
            <td class="column" colspan="4">出生年月</td>
            <td class="value" colspan="2" v-show="isEdit" ><input type="text" v-model="information.birthDate"> </td>
            <td class="value" colspan="2" v-show="!isEdit">{{information.birthDate}}</td>
            <td colspan="1" rowspan="8" class="column">教学工作</td>
            <td colspan="11" class="column">教学工作量（其他教学工作量按本校教学工作量计算）</td>
            <td colspan="4" class="column">主要教学业绩</td>
            <td colspan="4" class="column">指导青年教师情况</td>
            <td colspan="2" rowspan="8" class="column">教务部门审核意见（盖章）：</td>
          </tr>
          <tr>
            <td class="column" colspan="2">性别</td>
            <td class="value" colspan="2" v-show="isEdit"><input type="text" v-model="information.sex"></td>
            <td class="value" colspan="2" v-show="!isEdit">{{information.sex}}</td>
            <td class="column" colspan="4">参加工作时间</td>
            <td class="value" colspan="2" v-show="isEdit"><input type="text" v-model="information.workDate"></td>
            <td class="value" colspan="2" v-show="!isEdit">{{information.workDate}}</td>
            <td colspan="2" rowspan="7" class="column">按年度填写教学工作量</td>
            <td colspan="2" rowspan="2" class="column">年度</td>
            <td colspan="4" class="column">课堂教学（学时）</td>
            <td colspan="3" rowspan="2" class="column">其他教学工作量</td>
            <td colspan="4" class="value" rowspan="4" v-show="isEdit"><textarea cols="auto" rows="10" v-model="information.mostTeach"></textarea></td>
            <td colspan="4" class="value" rowspan="4" v-show="!isEdit">{{information.mostTeach}}</td>
            <td colspan="4" class="value" rowspan="4" v-show="isEdit"><textarea cols="auto" rows="10" v-model="information.teachTeacher"></textarea></td>
            <td colspan="4" class="value" rowspan="4" v-show="!isEdit">{{information.teachTeacher}}</td>
          </tr>
          <tr>
            <td class="column" colspan="4">现任技术职务</td>
            <td class="value" colspan="2" v-show="isEdit"><input type="text" v-model="information.job"></td>
            <td class="value" colspan="2" v-show="!isEdit">{{information.job}}</td>
            <td class="column" colspan="2">获得时间</td>
            <td class="value" colspan="2" v-show="isEdit"> <input type="text" v-model="information.jobTime"></td>
            <td class="value" colspan="2" v-show="!isEdit">{{information.jobTime}}</td>
            <td class="column" colspan="2">理论教学</td>
            <td class="column" colspan="2">实践教学</td>
          </tr>
          <tr>
            <td class="column" colspan="2">外语成绩</td>
            <td class="value" colspan="2" v-show="isEdit"><input type="text" v-model="information.foreignLanguage"> </td>
            <td class="value" colspan="2" v-show="!isEdit">{{information.foreignLanguage}}</td>
            <td class="column" colspan="4">计算机成绩</td>
            <td class="value" colspan="2" v-show="isEdit"><input type="text" v-model="information.csLevel"> </td>
            <td class="value" colspan="2" v-show="!isEdit">{{information.csLevel}}</td>
            <td colspan="2" class="value" rowspan="5" v-show="isEdit"><input type="text" v-model="information.year"></td>
            <td colspan="2" class="value" rowspan="5" v-show="!isEdit">{{information.year}}</td>
            <td colspan="2" class="value" rowspan="5" v-show="isEdit"><input type="text" v-model="information.theoryTeach"></td>
            <td colspan="2" class="value" rowspan="5" v-show="!isEdit">{{information.theoryTeach}}</td>
            <td colspan="2" class="value" rowspan="5" v-show="isEdit"><input type="text" v-model="information.practicalTeach"></td>
            <td colspan="2" class="value" rowspan="5" v-show="!isEdit">{{information.practicalTeach}}</td>
            <td colspan="3" class="value" rowspan="5" v-show="isEdit"><input type="text" v-model="information.otherTeach"></td>
            <td colspan="3" class="value" rowspan="5" v-show="!isEdit">{{information.otherTeach}}</td>
          </tr>
          <tr>
            <td class="column" colspan="2">最高学历</td>
            <td class="value" colspan="2" v-show="isEdit"><input type="text" v-model="information.education"> </td>
            <td class="value" colspan="2" v-show="!isEdit">{{information.education}}</td>
            <td class="column" colspan="4">最高学位</td>
            <td class="value" colspan="2" v-show="isEdit"><input type="text" v-model="information.degree"> </td>
            <td class="value" colspan="2" v-show="!isEdit">{{information.degree}}</td>
          </tr>
          <tr>
            <td class="column" colspan="2">现从事专业</td>
            <td class="value" colspan="2" v-show="isEdit"><input type="text" v-model="information.workMajor"></td>
            <td class="value" colspan="2" v-show="!isEdit">{{information.workMajor}}</td>
            <td class="column" colspan="4">是否破格</td>
            <td class="value" colspan="2" v-show="isEdit"><input type="text" v-model="information.isException"></td>
            <td class="value" colspan="2" v-show="!isEdit">{{information.isException}}</td>
            <td colspan="8" class="column" >任课教程</td>
          </tr>
          <tr>
            <td class="column" colspan="8">毕业学校及专业</td>
            <td class="column" colspan="2">毕业时间</td>
            <td colspan="8" class="value" rowspan="2" v-show="isEdit"><input type="text" v-model="information.teachCourse"></td>
            <td colspan="8" class="value" rowspan="2" v-show="!isEdit">{{information.teachCourse}}</td>
          </tr>
          <tr>
            <td class="value" colspan="8" v-show="isEdit"><input type="text" v-model="information.schoolAndMajor"></td>
            <td class="value" colspan="8" v-show="!isEdit">{{information.schoolAndMajor}}</td>
            <td class="value" colspan="2" v-show="isEdit"><input type="text" v-model="information.dateOfGraduation"></td>
            <td class="value" colspan="2" v-show="!isEdit">{{information.dateOfGraduation}}</td>
          </tr>
          <!-- 考核情况 -->
          <tr>
            <td  class="column" colspan="10">近五年年度考核情况</td>
            <td colspan="1" rowspan="8" class="column">科研工作</td>

            <td colspan="2" rowspan="4" class="column">主要著作或论文（标题、刊物名称、发表时间、作者排名:代表作）</td>
            <td colspan="4" class="column">论文总数</td>
            <td colspan="2" rowspan="1" class="value" v-show="isEdit"><input type="text" v-model="information.papers"></td>
            <td colspan="2" rowspan="1" class="value" v-show="!isEdit">{{information.papers}}</td>
            <td colspan="9" class="column">专(译〉著﹑国家级规划教材﹑省级规划教材数</td>
            <td colspan="2" rowspan="1" class="value" v-show="isEdit"><input type="text" v-model="information.materials"></td>
            <td colspan="2" rowspan="1" class="value" v-show="!isEdit">{{information.materials}}</td>
            <td colspan="2" rowspan="8" class="column">科研部门审核意见(盖章): 科研部门审核人签名:</td>
          </tr>
          <tr>
            <td class="column" colspan="2" rowspan="1">年度</td>
            <td class="column" colspan="2" rowspan="1">年度</td>
            <td class="column" colspan="2" rowspan="1">年度</td>
            <td class="column" colspan="2" rowspan="1">年度</td>
            <td class="column" colspan="2" rowspan="1">年度</td>
            <td colspan="17" rowspan="2" class="value" v-show="isEdit"><textarea cols="80" rows="5" v-model="information.detailsOfpapers"></textarea></td>
            <td colspan="17" rowspan="2" class="value" v-show="!isEdit">{{information.detailsOfpapers}}</td>
          </tr>
          <tr>
            <td class="value" colspan="2" rowspan="1" v-show="isEdit"><input type="text" v-model="information.year1"></td>
            <td class="value" colspan="2" rowspan="1" v-show="!isEdit">{{information.year1}}</td>
            <td class="value" colspan="2" rowspan="1" v-show="isEdit"><input type="text" v-model="information.year2"></td>
            <td class="value" colspan="2" rowspan="1" v-show="!isEdit">{{information.year2}}</td>
            <td class="value" colspan="2" rowspan="1" v-show="isEdit"><input type="text" v-model="information.year3"></td>
            <td class="value" colspan="2" rowspan="1" v-show="!isEdit">{{information.year3}}</td>
            <td class="value" colspan="2" rowspan="1" v-show="isEdit"><input type="text" v-model="information.year4"></td>
            <td class="value" colspan="2" rowspan="1" v-show="!isEdit">{{information.year4}}</td>
            <td class="value" colspan="2" rowspan="1" v-show="isEdit"><input type="text" v-model="information.year5"></td>
            <td class="value" colspan="2" rowspan="1" v-show="!isEdit">{{information.year5}}</td>
          </tr>

          <!-- 左下审核框 -->
          <tr>
            <td rowspan="2" colspan="10" class="column">
              工作经历与现任职以来的继续教育情况
            </td>
            <td colspan="4" rowspan="1" class="column">主持研究项目数</td>
            <td colspan="1" rowspan="1" class="value" v-show="isEdit"><input type="text" v-model="information.projectNumber"></td>
            <td colspan="1" rowspan="1" class="value" v-show="!isEdit">{{information.projectNumber}}</td>
            <td colspan="4" rowspan="1" class="column">参与研究数</td>
            <td colspan="1" rowspan="1" class="value" v-show="isEdit"><input type="text" v-model="information.studies"></td>
            <td colspan="1" rowspan="1" class="value" v-show="!isEdit">{{information.studies}}</td>
            <td colspan="1" rowspan="1" class="column">科研经费</td>
            <td colspan="1" rowspan="1" class="value" v-show="isEdit"><input type="text" v-model="information.money"></td>
            <td colspan="1" rowspan="1" class="value" v-show="!isEdit">{{information.money}}</td>
            <td colspan="2" rowspan="1" class="column">技术开发或管理项目</td>
            <td colspan="1" rowspan="1" class="value" v-show="isEdit"><input type="text" v-model="information.managerProject"></td>
            <td colspan="1" rowspan="1" class="value" v-show="!isEdit">{{information.managerProject}}</td>
            <td colspan="1" rowspan="1" class="column">专利数</td>
            <td colspan="1" rowspan="1" class="value" v-show="isEdit"><input type="text" v-model="information.patent"></td>
            <td colspan="1" rowspan="1" class="value" v-show="!isEdit">{{information.patent}}</td>
          </tr>
          <!-- 换行 -->
          <tr>

          </tr>
          <tr>
            <td class="value" colspan="10" rowspan="3" v-show="!isEdit">
              {{information.workAndNowDetails}}
              <div class="leftFa">
                <div class="left1">审核人签名：</div>
                <div class="left2">人事部门盖章：</div>
              </div>
            </td>
            <td class="value" colspan="10" rowspan="3" v-show="isEdit">
              <textarea cols="30" rows="6" v-model="information.workAndNowDetails"></textarea>
              <div class="leftFa" v-show="!isEdit">
                <div class="left1">审核人签名：</div>
                <div class="left2">人事部门盖章：</div>
              </div>
            </td>
            <td colspan="2" rowspan="8" class="column">承担或参与的科研技术开发项目（项目名称、立项审批单位、项目编号及鉴定获奖情况）</td>
            <td colspan="17" rowspan="5" class="value" v-show="isEdit"><textarea cols="80" rows="6" v-model="information.detailsOfStudies" class="input_left"></textarea></td>
              <td colspan="17" rowspan="5" class="value" v-show="!isEdit">{{information.detailsOfStudies}}</td>
          </tr>
        </table>
        <br />
        <div style="line-height: 30px; color: #333333;">
          <div>*此记录基本信息栏为电子录入记录。</div>
          <div>注1.请保证数据的准确性</div>
          <div>&nbsp;&nbsp;&nbsp;2.时间格式为yyyy-mm-dd</div>
        </div>
        <br />
      </div>
    </div>
      <!-- //操作按钮 -->
      <div class="button_group">
      <el-button type="primary" v-show="!isEdit" @click="isEdit=!isEdit">编辑</el-button>
      <el-button type="success" v-show="isEdit" @click="save">完成</el-button>
      <el-button type="primary" @click="printSendTable">打印</el-button>
    </div>
  </div>
</template>
<script>
import axios from 'axios'
import util from '@/util/util'

export default {
  data () {
    return {
      isEdit: false,
      tableDataById: {},
      information: {
        company: '马来西亚',
        name: '王重阳',
        jobDeclaration: '副教授',
        major: '计算机',
        birthDate: '1995年6月',
        sex: '男',
        workDate: '1999年6月',
        job: '教授',
        jobTime: '1999年1月',
        foreignLanguage: '91',
        csLevel: '91',
        education: '本科',
        degree: '学士',
        workMajor: '教师',
        // 是否破格
        isException: '是',
        schoolAndMajor: '四川师范大学计算机系',
        dateOfGraduation: '1999年4月',
        year1: '1992',
        year2: '1992',
        year3: '1992',
        year4: '1992',
        year5: '1992',
        year: '1999',
        // 理论教学时长
        theoryTeach: '12',
        // 实践教学时长
        practicalTeach: '12',
        // 其他教学工作量
        otherTeach: '',
        // 主要教学业绩
        mostTeach: '教学三个班',
        // 指导青年教育情况
        teachTeacher: '5人',
        // 任课教程
        teachCourse: '物理',
        papers: '12',
        materials: '10',
        detailsOfpapers: '完成论文30余篇 教育三百兆',
        // 工作以来继续教育情况
        workAndNowDetails: '完成论文30余篇 教育三百兆',
        projectNumber: '12',
        studies: '20',
        money: '122W',
        managerProject: '30',
        patent: '100',
        detailsOfStudies: '完成论文30余篇 教育三百兆'
      }
    }
  },
  props: [''],
  watch: {},
  computed: {},
  created () {
    axios.get(`/api/findUserById/${util.userId}`).then(res => {
      this.information = res.data
      // company=company
      // name=name
      // jobDeclaration=jobDeclaration
      // major=major
      // birthDate=birthDate
      // sex=sex
      // workDate=workDate
      // job=job
      // jobTime=jobTime
      // foreignLanguage=foreignLanguage
      // csLevel=csLevel
      // education=education
      // degree=degree
      // workMajor=workMajor
      // isException=isException
      // schoolAndMajor=schoolAndMajor
      // dateOfGraduation=dateOfGraduation
      // year1=year1
      // year2=year2
      // year3=year3
      // year4=year4
      // year5=year5
      // year=year
      // theoryTeach=theoryTeach
      // practicalTeach=practicalTeach
      // otherTeach=otherTeach
      // mostTeach=mostTeach
      // teachTeacher=teachTeacher
      // teachCourse=teachCourse
      // papers=papers
      // materials=materials
      // detailsOfpapers=detailsOfpapers
      // workAndNowDetails=workAndNowDetails
      // projectNumber=projectNumber
      // studies=studies
      // money=money
      // managerProject=managerProject
      // patent=patent
      // detailsOfStudies=detailsOfStudies
    })
  },
  methods: {
    // 打印交接单
    printSendTable () {
      this.$print(this.$refs.print)
    },
    show () {
      axios.get(`/api/findUserById/${util.userId}`).then(res => {
        this.information = res.data
        this.saveAuditing()
      })
    },
    save () {
      this.isEdit = !this.isEdit
      axios.put('/api/updateUserInformation', this.information).then(res => {
        this.show()
        setTimeout(() => {
          this.getSelect1()
        }, 1000)
        setTimeout(() => {
          this.getSelect2()
        }, 2000)
        setTimeout(() => {
          this.getSelect3()
        }, 3000)
      })
    },
    getSelect1 () {
      axios.get(`/api/findFirstByAuditingId/${util.userId}/1`).then(res => {
        this.tableDataById = res.data
        this.tableDataById.specialty = this.information.jobDeclaration
        this.saveAuditing()
      })
    },
    getSelect2 () {
      axios.get(`/api/findFirstByAuditingId/${util.userId}/2`).then(res => {
        this.tableDataById = res.data
        this.tableDataById.specialty = this.information.jobDeclaration
        this.saveAuditing()
      })
    },
    getSelect3 () {
      axios.get(`/api/findFirstByAuditingId/${util.userId}/3`).then(res => {
        this.tableDataById = res.data
        this.tableDataById.specialty = this.information.jobDeclaration
        this.saveAuditing()
      })
    },
    // 保存
    saveAuditing () {
      axios.put('/api/updateFirstAuditing', this.tableDataById).then(res => {
        //   setTimeout(() =>{
        //   this.show()
        // },1000)
      })
      this.$message({
        type: 'success',
        message: '成功'
      })
    }
  }
}
</script>

<style>
.my-multi-table{
  margin-top: 30px;
}
input{
  width: 100%;
  height: 100%;
}
.input_left{
  text-align: left;
}
.button_group {
  margin-top: 30px;
  margin-right: 30px;
  display: flex;
  align-items: center;
  justify-content: flex-end;
}
.print {
  width: 90%;
  margin: 0 auto;
  max-width: 1280px;
}
.table {
  border-collapse: collapse;
  border-spacing: 0;
  background-color: transparent;
  display: table;
  width: 100%;
  max-width: 100%;
  width: 800px;
  margin: 0 auto;
}
.table td {
  text-align: center;
  width:30px;
  vertical-align: middle;
  font-size: 12px;
  font-family: "Arial Normal", "Arial";
  color: #333333;
  padding: 8px 12px;
}
.table-bordered {
  border: 1px solid #ddd;
}
.column {
  width: 30px;
  height: 30px;
  border: 1px solid #333;
  background: #f1f1f1;
}
.value {
  width: 70px;
  height: 30px;
  border: 1px solid #333;
}
.el-main {
    line-height: 10px;
    height: 900px;
}

.left1{
  position: relative;
  top: 20px;
}
.left2{
  position: relative;
  top: 30px;
}
</style>
