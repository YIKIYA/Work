package com.school.backend_school.mapper;

import com.school.backend_school.domain.User;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface UserMapper {

    @Select("Select * from user")
    List<User> getSelect();

    @Select("Select count(*) from user")
    int total();

    @Insert("insert into user(userId,username,userpassword,type,submit) values (#{userId},#{username},#{userpassword},#{type},0)")
    void insert(User user);

    @Delete("delete from user where userId=#{id}")
    void delete(int id);

    @Update("update user set username=#{username},userpassword=#{userpassword} where userId=#{userId}")
    void update(User user);

    @Select("select * from user where userId=#{id}")
    User getSelectById(int id);

    @Select("select count(*) from user where username=#{username} and userpassword=#{password}")
    int login(String username, String password);
}
