package com.school.backend_school.service;

import com.school.backend_school.domain.Power;
import com.school.backend_school.mapper.PowerMapper;
import com.school.backend_school.service.Impl.PowerServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PowerService implements PowerServiceImpl {

    @Autowired
    private PowerMapper powerMapper;

    @Override
    public List<Power> findAll() {
        return powerMapper.getSelect();
    }

    @Override
    public List<Power> findByType(int type) {
        return powerMapper.getSelectByType(type);
    }

    @Override
    public int count(int type) {
        return powerMapper.total(type);
    }

    @Override
    public void save(Power power) {
        powerMapper.insert(power);
    }
}
