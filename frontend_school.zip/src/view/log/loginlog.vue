<template>
<div>
<!-- 面包屑导航区 -->
<el-breadcrumb separator-class="el-icon-arrow-right">
<el-breadcrumb-item>首页</el-breadcrumb-item>
<el-breadcrumb-item>日志</el-breadcrumb-item>
<el-breadcrumb-item>登录日志</el-breadcrumb-item>
</el-breadcrumb>
<el-card
style="width: 100%;height: 100%"
>
<!-- 导出信息 -->
<download-excel :data="tableData" :fields="excelFields" style="display:
inline; margin-left: 10px">
<el-button type="primary" style="float: right;margin-bottom: 15px;"
icon="el-icon-download">导出信息</el-button>
</download-excel>
<!-- 渲染数据 -->
<el-table
:data="tableData"
border
stripe
:default-sort="{prop: 'date', order: 'descending'}"
>
<el-table-column
label="#"
type="index"
/>
<el-table-column
label="登录时间"
sortable
prop="loginTime"
/>
<el-table-column
label="用户名"
prop="username"
align="left"
/>
<el-table-column
label="真实姓名"
prop="userRealName"
align="left"
/>
<el-table-column
label="IP地址"
prop="ip"
width="300px"
/>
<el-table-column
label="操作"
align="center"
width="150px"
>
<!-- <template slot-scope="scope">-->
<el-button
size="mini"
type="danger"
icon="el-icon-delete"
@click="handleDelete(scope.row)"
>删 除</el-button>
<!--</template> -->
</el-table-column>
</el-table>
<!-- 分页 -->
<el-pagination
style="text-align: right;"
:current-page="currentPage"
:page-sizes="[3, 5, 10, 20]"
:page-size="pageSize"
layout="total, sizes, prev, pager, next, jumper"
:total="totalNum"
@size-change="handleSizeChange"
@current-change="handleCurrentChange"
/>
</el-card>
</div>
</template>

<script>
import axios from 'axios'
export default {
  name: 'Loginlog',
  data () {
    return {
      tableData: [{
        loginTime: '2021-11-07 21:31:13',
        username: '1号',
        userRealName: '徐航',
        ip: '127.0.0.1'
      },
      {
        loginTime: '2021-11-07 21:31:13',
        username: '1号',
        userRealName: '徐航',
        ip: '127.0.0.1'
      },
      {
        loginTime: '2021-11-07 21:31:13',
        username: '1号',
        userRealName: '徐航',
        ip: '127.0.0.1'
      }],
      currentPage: 1,
      pageSize: 10,
      totalNum: 0,
      // 将表格中的信息导出为Excel的文件头
      excelFields: {
        '登录时间': 'loginTime',
        '用户名': 'username',
        '真实姓名': 'userRealName',
        'IP地址': 'ip'
      }
    }
  },
  created () {
    this.init()
  },
  methods: {
    // 获取后端数据
    init () {
      axios.get(`/log/getUserLog?
pageNum=${this.currentPage}&pageSize=${this.pageSize}`)
        .then(res => {
          console.log(res)
          this.tableData = res.data.data.list
          this.totalNum = res.data.data.total
          for (let index = 0; index < this.tableData.length; index++) {
            this.tableData[index].loginTime =
this.getdata(this.tableData[index].loginTime)
          }
        })
        .catch(err => {
          console.error(err)
        })
    },
    // 转换时间
    getdata (data) {
      var date = new Date(data)
      var Y = date.getFullYear() + '-'
      var M = (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1)
        : date.getMonth() + 1) + '-'
      var D = (date.getDate() < 10 ? '0' + date.getDate() : date.getDate()) + ''
      var h = (date.getHours() < 10 ? '0' + date.getHours() : date.getHours()) +
':'
      var m = (date.getMinutes() < 10 ? '0' + date.getMinutes()
        : date.getMinutes()) + ':'
      var s = (date.getSeconds() < 10 ? '0' + date.getSeconds()
        : date.getSeconds())
      return Y + M + D + h + m + s
    },
    // 删除日志
    handleDelete (row) {
      this.$confirm('此操作将永久删除该条日志, 是否继续?', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        axios.post('/log/deleteUserLog', {
          userLogList: [
            {
              logTime: row.loginTime
            }
          ]
        })
          .then(res => {
            this.init()
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
          })
          .catch(err => {
            console.error(err)
            this.$message({
              type: 'error',
              message: '删除失败!'
            })
          })
      }).catch((err) => {
        console.log(err)
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    handleSizeChange (val) {
      this.pageSize = val
      this.init()
    },
    handleCurrentChange (val) {
      this.currentPage = val
      this.init()
    }
  }
}
</script>


