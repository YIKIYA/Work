package com.school.backend_school.utils;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Random;

//验证码工具类
public class ActionCode {
    //创建成员变量
    private int width = 100;//验证码图片宽度
    private int height = 30;//验证码图片高度
    //浏览器字体
    private String[] fontNames = {"宋体","楷体","隶书","微软雅黑"};
    //验证码图片颜色
    private Color bgColor = new Color(255,255,255);

    //通过随机数来获得验证码
    private Random random = new Random();
    private String codes = "0123456789abcdefghijklmnopqrstuvwsyzABCDEFGHIJKLMNOPQRSTUVWSYZ";
    //随机字符串
    private String text;

    //获取一个随机的颜色
    private Color randomColor(){
        int red = random.nextInt(250);
        int green = random.nextInt(250);
        int blue = random.nextInt(250);
        return new Color(red, green, blue);
    }

    //随机获得一个字体
    private Font randomFont(){
        String fontName = fontNames[random.nextInt(fontNames.length)];
        int style = random.nextInt(4);
        int size = random.nextInt(5)+24;
        return new Font(fontName, style, size);
    }

    //随机获得一个字符
    private char randomChar(){
        return codes.charAt(random.nextInt(codes.length()));
    }

    //生成一个空白的图片
    private BufferedImage createImage(){
        //图片
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        //二维
        Graphics2D g2 = (Graphics2D)image.getGraphics();
        //设置背景色
        g2.setColor(randomColor());
        //长方形
        g2.fillRect(0,0,width,height);
        return image;
    }

    //干扰线
    private void drawLine(BufferedImage image){
        Graphics2D g2 = (Graphics2D)image.getGraphics();
        int num = 5 ;
        for (int i = 0; i < num; i++) {
            int x1 = random.nextInt(width);
            int y1 = random.nextInt(height);
            int x2 = random.nextInt(width);
            int y2 = random.nextInt(height);
            g2.setColor(randomColor());
            g2.setStroke(new BasicStroke(1.5f));
            g2.drawLine(x1,y1,x2,y2);
        }
    }

    //获取验证码图片
    public BufferedImage getImage(){
        //调用创建方法
        BufferedImage image = createImage();
        //二维图像
        Graphics2D g2 = (Graphics2D)image.getGraphics();
        //拼接字符串的对象
        StringBuilder sb = new StringBuilder();
        //添加内容
        for (int i = 0; i < 4; i++) {
            String s = randomChar()+ "";
            sb.append(s);
            g2.setColor(randomColor());
            g2.setFont(randomFont());
            float x = i*width*1.0f/4;
            g2.drawString(s,x,height-8);
        }
        //验证码的字符串
        this.text = sb.toString();
        //干扰线
        drawLine(image);
        return image;
    }

    //获取验证码的内容
    public String getText(){
        return text;
    }

    //把图片输出流获取到
    public static void output(BufferedImage image, OutputStream out){
        try {
            ImageIO.write(image,"JPEG",out);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
