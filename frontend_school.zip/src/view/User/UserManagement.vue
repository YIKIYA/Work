<template>
  <el-card>
    <el-header>
      <center><span>管理用户</span></center>
    </el-header>
    <div>
      <el-table :data="tableData" style="width: 100%">
        <el-table-column label="用户id" width="180">
          <template slot-scope="scope">
            <span style="margin-left: 10px">{{ scope.row.userId }}</span>
          </template>
        </el-table-column>
        <el-table-column label="用户姓名" width="180">
          <template slot-scope="scope">
            <span style="margin-left: 10px">{{ scope.row.name }}</span>
          </template>
        </el-table-column>
        <el-table-column label="性别" width="150">
          <template slot-scope="scope">
            <span style="margin-left: 10px">{{ scope.row.sex }}</span>
          </template>
        </el-table-column>
        <el-table-column label="身份证号" width="240">
          <template slot-scope="scope">
            <span style="margin-left: 10px">{{ scope.row.id }}</span>
          </template>
        </el-table-column>
        <el-table-column label="电话" width="180">
          <template slot-scope="scope">
            <span style="margin-left: 10px">{{ scope.row.phone }}</span>
          </template>
        </el-table-column>
        <el-table-column label="邮箱" width="180">
          <template slot-scope="scope">
            <span style="margin-left: 10px">{{ scope.row.email }}</span>
          </template>
        </el-table-column>
        <el-table-column label="操作" width="180">
          <template slot-scope="scope">
            <el-button size="mini" type="danger" @click="handleDelete(scope.row.userId)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <div class="pag">
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="limitPage.page"
        :page-sizes="[5, 10, 15, 20]"
        :page-size="limitPage.limit"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total">
      </el-pagination>
    </div>
  </el-card>
</template>

<script>
import axios from 'axios'

export default {
  data () {
    return {
      tableData: [

      ],
      limitPage: {
        page: 1,
        limit: 5
      },
      total: 0
    }
  },
  created () {
    this.showPage()
  },
  methods: {
    // 分页
    handleSizeChange (val) {
      this.limitPage.limit = val
      this.showPage()
    },
    handleCurrentChange (val) {
      this.limitPage.page = val
      this.showPage()
    },
    showPage () {
      axios.post(`/api/findRegisterByPage/${this.limitPage.page}/${this.limitPage.limit}`).then(res => {
        this.tableData = res.data
        this.count()
      })
    },
    count () {
      axios.get(`/api/registerCount`).then(res => {
        this.total = res.data
      })
    },
    handleDelete (userId) {
      this.$confirm('是否删除', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        axios.delete(`/api/deleteRegisterCount/${userId}`).then(res => {
          this.showPage()
        })
        this.$message({
          type: 'success',
          message: '删除成功'
        })
      })
    }
  }
}
</script>

<style>
.pag{
  text-align: center;
}
</style>
