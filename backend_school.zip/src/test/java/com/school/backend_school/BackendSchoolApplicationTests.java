package com.school.backend_school;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BackendSchoolApplicationTests {

    @Test
    void contextLoads() {
    }

}
