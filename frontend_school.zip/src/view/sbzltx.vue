<template>
  <el-container>
    <el-header style="text-align:left">
      <el-button type="primary" @click="saveDoctor">添加信息 </el-button>
    </el-header>
    <el-main>
      <el-table :data="tableData" stripe style="width: 100%">
        <el-table-column label="姓名" prop="name" width="180"></el-table-column>
        <el-table-column label="性别" prop="sex" width="180"></el-table-column>
        <el-table-column label="年龄" prop="age"></el-table-column>
      </el-table>
    </el-main>
    <!--弹出框-->
    <template>
      <el-dialog title="医生信息" :visible.sync="dialogFormVisible" width="500px">
        <el-form :model="tPerson">
          <el-form-item label="姓名" :label-width="formLabelWidth">
            <el-input v-model="tPerson.name"></el-input>
          </el-form-item>
          <el-form-item label="性别" :label-width="formLabelWidth">
            <el-select v-model="tPerson.sex" placeholder="请选择">
              <el-option label="男" value="男"></el-option>
              <el-option label="女" value="女"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="年龄" :label-width="formLabelWidth">
            <el-input-number v-model="tPerson.age"></el-input-number>
          </el-form-item>
        </el-form>
        <div slot="footer" class="dialog-footer">
          <el-button @click="resetData">清 空</el-button>
          <el-button @click="dialogFormVisible = false">取 消</el-button>
          <el-button type="primary" @click="saveOrUpdate">确 定</el-button>
        </div>
      </el-dialog>
    </template>

  </el-container>
</template>

<script>
import axios from 'axios'

export default {
  name: 'Doctor',
  data () {
    return {
      tableData: null,
      tPerson: {},
      dialogFormVisible: false,
      formLabelWidth: '120px'
    }
  },
  // 页面加载时执行
  created () {
    this.show()
  },
  // 自定义函数
  methods: {
    // 数据列表
    show () {
      axios.get('/api/showDoctor').then(res => {
        this.tableData = res.data
      })
    },
    // 显示保存窗口
    saveDoctor () {
      this.dialogFormVisible = true
    },
    // 清空数据
    resetData () {
      this.tPerson = {}
    },
    // 保存或者更新
    saveOrUpdate () {
      this.save()
    },
    // 保存到数据库
    save () {
      // 关闭窗口
      this.dialogFormVisible = false
      axios.post('/api/saveDoctor', this.tPerson).then(res => {
        this.show()
      })
      this.$message({
        type: 'success',
        message: '保存成功'
      })
    },
    updata () {

    }
  }
}
</script>

<style>
  .el-table .warning-row {
    background: rgb(255, 255, 255);
  }
  .el-table .success-row {
    background: #ffffff;
  }
</style>
