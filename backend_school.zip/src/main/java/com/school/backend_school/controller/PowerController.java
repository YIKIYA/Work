package com.school.backend_school.controller;

import com.school.backend_school.domain.Power;
import com.school.backend_school.service.PowerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class PowerController {
    @Autowired
    private PowerService powerService;

    @GetMapping("/Power")
    public Object show(){
        return powerService.findAll();
    }

    @GetMapping("/findByType/{type}")
    public List<Power> findByType(@PathVariable int type){
        return  powerService.findByType(type);
    }

    @GetMapping("/powerTotal/{type}")
    public int count(@PathVariable int type){
        return powerService.count(type);
    }

    @PostMapping("/savePower")
    public String saveDoctor(@RequestBody Power power){
        if (power.getPid()==0){
            return "插入权限失败";
        }else if(power.getPname()==null){
            return "插入权限失败";
        }
        powerService.save(power);
        return "插入权限成功";
    }
}
