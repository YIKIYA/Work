<template>
<el-container>
  <el-header>
    <img src="../assets/head.png" width= "100%" height="60px"/>
  </el-header>
  <el-main>
    <img src="../assets/login.png" width="60%" height="100%"/>
    <div class="login_box">
      <!-- <div class="avatar_box"> -->
        <!--头像-->
        <!--<img src="../assets/logo.png" alt />-->
      <!-- </div> -->
      <!--添加表单-->
      <el-form
        ref="loginFormRef"
        :model="loginForm"
        :rules="loginRules"
        class="login_form"
        label-width="0px"
      >
        <el-form-item prop="username">
          <!-- <img src="../assets/userImg.png" width="40px"> -->
          <el-input v-model="loginForm.username" prefix-icon="iconfont icondenglu" ></el-input>
        </el-form-item>
        <el-form-item prop="userpassword">
          <!-- <img src="../assets/passwordImg.png" width="40px" alt=""> -->
          <el-input v-model="loginForm.userpassword" prefix-icon="iconfont iconmima" type="password"></el-input>
        </el-form-item>
      <div style="position:relative">
        <el-form-item prop="code">
          <el-input size="normal" type="text" v-model="loginForm.code"  placeholder="请点击图片更换验证码"
            @keydown.enter.native="submitLogin" style="width:250px"></el-input>
          <!-- 验证码的图片 -->
          <img :src="codeUrl" @click="updateCode" style="cursor: pointer; position: absolute;bottom:5px;margin-left:5px">
        </el-form-item>
      </div>
        <el-form-item class="btns">
          <el-button type="primary" @click="login">登录</el-button>
          <el-button type="info" @click="resetLoginForm">重置</el-button>
          <el-button type="info" @click="register">注册</el-button>
          <el-button type="info" @click="Forget">忘记密码</el-button>
        </el-form-item>
      </el-form>
    </div>
  </el-main>
  <el-footer height="40%" background="#333333">
    <!-- //通知管理 -->
      <el-button class="information_button" @click="drawer1 = true" type="primary">
      <div class="information" >
      <el-table
      :header-cell-style="tableHeaderColor"
      :data="tableData1"
      style="width: 100%">
      <el-table-column :show-overflow-tooltip="true"
        label="通知管理"
        width="300">
        <template slot-scope="scope">
          <span style="margin-left: 10px" @click="getNote(scope.row.information)">{{ scope.row.information }}</span>
        </template>
      </el-table-column>
      </el-table>
      </div>
      </el-button>

      <el-drawer
        :visible.sync="drawer1"
        :with-header="false">
        <span class="notetitle">通知详情</span>
        <div>{{drawerData}}</div>
      </el-drawer>
    <!-- //政策法规 -->
    <el-button class="information_button" @click="drawer2 = true" type="primary">
    <div class="information" >
      <el-table
      :header-cell-style="tableHeaderColor"
      :data="tableData2"
      style="width: 100%">
      <el-table-column :show-overflow-tooltip="true"
        label="政策法规"
        width="300">
        <template slot-scope="scope">
          <span style="margin-left: 10px" @click="getNote(scope.row.information)">{{ scope.row.information }}</span>
        </template>
      </el-table-column>
      </el-table>
    </div>
    </el-button>
    <!-- 抽屉2内容 -->
    <el-drawer
      :visible.sync="drawer2"
      :with-header="false">
      <span class="notetitle">政策法规</span>
      <div>{{drawerData}}</div>
   </el-drawer>
<!-- //使用说明 -->
  <el-button class="information_button" @click="drawer3 = true" type="primary">
    <div class="information" >
      <el-table
      :header-cell-style="tableHeaderColor"
      :data="tableData3"
      style="width: 100%">
      <el-table-column :show-overflow-tooltip="true"
        label="使用说明"
        width="300">
        <template slot-scope="scope">
          <span style="margin-left: 10px" @click="getNote(scope.row.information)">{{ scope.row.information }}</span>
        </template>
      </el-table-column>
    </el-table>
    </div>
 </el-button>
  <!-- 抽屉3内容 -->
  <el-drawer
    :visible.sync="drawer3"
    :with-header="false">
    <span class="notetitle">使用说明</span>
    <div>{{drawerData}}</div>
  </el-drawer>

<!-- 常见问题 -->
    <el-button class="information_button" @click="drawer4 = true" type="primary">
      <div class="information" >
            <el-table
            :header-cell-style="tableHeaderColor"
            :data="tableData4"
            style="width: 100%">
            <el-table-column :show-overflow-tooltip="true"
              label="常见问题"
              width="300">
            <template slot-scope="scope">
                <span style="margin-left: 10px" @click="getNote(scope.row.information)">{{ scope.row.information }}</span>
            </template>
            </el-table-column>
            </el-table>
          </div>
    </el-button>
  <!-- 抽屉4内容 -->
    <el-drawer
        :visible.sync="drawer4"
        :with-header="false">
        <span class="notetitle">常见问题</span>
        <div>{{drawerData}}</div>
    </el-drawer>
  </el-footer>
</el-container>
</template>
<script>
import axios from 'axios'
import util from '@/util/util'

export default {
  data () {
    return {
      codeUrl: '',
      loginForm: {
        username: '',
        userpassword: '',
        code: ''
      }, // 开始校验信息
      loginRules: {
        username: [
          { required: true, message: '请输入用户名', trigger: 'blur' },
          { min: 2, max: 8, message: '长度在 2 到 8 个字符', trigger: 'blur' }
        ],
        userpassword: [
          { required: true, message: '请输入密码', trigger: 'blur' },
          { min: 3, max: 8, message: '密码为 3~8 位', trigger: 'blur' }
        ],
        code: [
          {required: true, message: '请输入验证码', trigger: 'blur'}
        ]
      },
      list: [],
      tableData1: [],
      tableData2: [],
      tableData3: [],
      tableData4: [],
      drawerData: '点错了哦',
      drawer1: false,
      drawer2: false,
      drawer3: false,
      drawer4: false

    }
  },
  created () { // 页面加载就应该调用验证码
    axios.get('/api/checkCode', {responseType: 'arraybuffer'}).then((res) => {
      this.codeUrl = 'data:image/png;base64,' + btoa(new Uint8Array(res.data).reduce((data, byte) => data + String.fromCharCode(byte), ''))
      this.getInformation()
    })
  },
  methods: {
    tableHeaderColor ({row, column, rowIndex, columnIndex}) { // 修改element-lable样式
      return 'font-wight:600;font-size:20px;'
    },
    resetLoginForm () {
      this.$refs.loginFormRef.resetFields()
    }, // 重置输入
    // 注册
    register () {
      this.$router.push('/register')
    },
    Forget () {
      this.$router.push('/forget')
    },
    updateCode () { // 点击图片更换验证码
      axios.get('/api/checkCode', {responseType: 'arraybuffer'}).then((res) => {
        this.codeUrl = 'data:image/png;base64,' + btoa(new Uint8Array(res.data).reduce((data, byte) => data + String.fromCharCode(byte), ''))
      })
    },
    getInformation () {
      axios.get('/api/information').then(res => {
        res.data.forEach((element) => {
          // eslint-disable-next-line eqeqeq
          if (element.ntype == 1) {
            this.tableData1.push(element)
          }
          // eslint-disable-next-line eqeqeq
          if (element.ntype == 2) {
            this.tableData2.push(element)
          }
          // eslint-disable-next-line eqeqeq
          if (element.ntype == 3) {
            this.tableData3.push(element)
          }
          // eslint-disable-next-line eqeqeq
          if (element.ntype == 4) {
            this.tableData4.push(element)
          }
        })
      })
    },
    getNote (note) {
      this.drawerData = note
    },
    getUserId () {
      axios.get(`/api//userId/${util.username}`).then(res => {
        util.userId = res.data
      })
    },
    login () {
      this.$refs.loginFormRef.validate(async valid => {
        if (!valid) { return }// 验证结果
        // 调用get请求解析端口返回值
        axios.post('/api/userLogin', this.loginForm).then(res => {
          if (res.data > -1) {
          // 回到主页面home
            util.type = res.data
            util.username = this.loginForm.username
            this.getUserId()
            this.$message.success('登录成功')
            this.$router.push('/Home')
          } else {
            this.$message.error('登录失败')
          }
        })
      })
    }
  }
}
</script>

<style>
  body{
    margin: 0px;
  }
  .el-input{
    background-color: rgb(0, 0, 0);
  }
  .el-main{
    background: #333333;
    padding: 0px;
  }
  .el-header{
    height:30px;
    padding-right: 0px;
    padding-left: 0px;
    padding:0px
  }
  .el-footer{
    position: relative;
    padding: 0px;
    height:30%;
    background:#333333;
  }
  .el-table{
    border-radius: 15px;
  }
  .notetitle{
    font-size: 24px;
    color: #000000;
  }

  /* // 登录框 */
  .login_box {
    width: 400px;
    height: 230px;
    background-color: #333333;
    border-radius: 3px;
    position: absolute;
    left: 80%;
    top: 30%;
    transform: translate(-45%, -25%);
  }
  .btns {
      display: flex;
      justify-content: center;
    }
  .login_form {
      position: absolute;
      bottom: 10%;
      width: 100%;
      padding: 0px;
      box-sizing: border-box;
    }
  .information{
    width: 100%;
    height: 100%;
    border: 1px solid rgb(0, 0, 0);
    border-radius: 15px;
    display: inline-block;
    margin: 0px;
    height: 300px;
    background-color:rgb(255, 255, 255)
  }

  .information_button{
    width: 23%;
    margin: 10px;
    margin-top: 0px;
    padding: 0px;
    border: 1px;
    color: #FFF;
    border-radius: 15px;
    background-color: #ffffff;
    border-color: rgb(255, 255, 255);
  }

</style>
