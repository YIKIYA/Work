import Vue from 'vue'
import Vuex from 'vuex'
// eslint-disable-next-line import/no-duplicates
import Router from 'vue-router'
// import Login from '@/view/Login'
import Home from '@/view/Home'
// import Doctor from '@/view/Doctor'
import sbxxtx from '@/view/sbxxtx'
// import Timeline from '@/view/Timeline'
// eslint-disable-next-line no-unused-vars
import Messageupdate from '@/view/Messageupdate'
import Personmessage from '@/view/Personmessage'
import historyup from '@/view/historyup'
// eslint-disable-next-line import/no-duplicates
import VueRouter from 'vue-router'
import loginlog from '@/view/log/loginlog'
import uselog from '@/view/log/uselog'
import adminlog from '@/view/log/adminlog'
// import associateProfessor from '@/view/Auditing/AuditingAssociateProfessor'
import professor from '@/view/Auditing/AuditingProfessor'
import approval from '@/view/ApplicationApproval/Approval'
import userManagement from '@/view/User/UserManagement'
import userType from '@/view/User/UserType'
// import menudata from '@/util/menudata'
Vue.use(Vuex)
Vue.use(Router)

const routes = [
  {
    path: '/',
    name: '首页',
    component: () => import('@/view/Login')
  },
  {
    path: '/register',
    name: '注册界面',
    component: () => import('@/view/Logother/register')
  },
  {
    path: '/forget',
    name: '忘记密码',
    component: () => import('@/view/Logother/Forget')
  },
  {
    path: '/Home',
    name: 'home',
    component: Home
  },
  {
    path: '/',
    name: '个人中心',
    component: Home,
    children: [
      {
        path: '/Personmessage',
        name: '个人信息',
        component: Personmessage
      }
      // {
      //   path: '/Messageupdate',
      //   name: '信息修改',
      //   component: Messageupdate
      // },
    ]
  },
  {
    path: '/',
    name: '职称申报',
    component: Home,
    children: [
      {
        path: '/sbxxtx',
        name: '申报资料填写',
        component: sbxxtx
      },
      {
        path: '/historyup',
        name: '历史提交查看',
        component: historyup
      }
    ]
  },
  {
    path: '/',
    name: '专家分配',
    component: Home,
    children: [
      {
        path: '/approval',
        name: '专家分配',
        component: approval
      }
    ]
  },
  {
    path: '/',
    name: '专家审核',
    component: Home,
    children: [
      // {
      //   path: '/associateProfessor',
      //   name: '副教授审核',
      //   component: associateProfessor
      // },
      {
        path: '/professor',
        name: '教授审核',
        component: professor
      }
    ]
  },
  {
    path: '/',
    name: '用户管理',
    component: Home,
    children: [
      {
        path: '/userManagement',
        name: '管理用户',
        component: userManagement
      },
      {
        path: '/userType',
        name: '分配角色',
        component: userType
      }
    ]
  },
  {
    path: '/',
    name: '日志管理',
    component: Home,
    children: [
      {
        path: '/loginlog',
        name: '登录日志',
        component: loginlog
      },
      {
        path: 'uselog',
        name: '操作日志',
        component: uselog
      },
      {
        path: '/adminlog',
        name: '系统日志',
        component: adminlog
      }
    ]
  }
  // {
  //   path: '',
  //   name: '',
  //   component:
  // }
  // children: [

  //   {
  //     path:'/Fhome',
  //     name:'Fhome',
  //     component:()=>import('@/view/Fhome')
  //   },
  //   {
  //     path:'/Personmessage',
  //     name:'Personmessage',
  //     component:()=>import('@/view/Personmessage')
  //   },
  //   {
  //     path:'/Messageupdate',
  //     name:'Messageupdate',
  //     component:()=>import('@/view/Messageupdate')
  //   },
  //   {
  //     path:'/Doctor1',
  //     name:'Doctor1',
  //     component:()=>import('@/view/Doctor1')
  //   },
  //   {
  //     path:'/Timeline',
  //     name:'Timeline',
  //     component:()=>import('@/view/Timeline')
  //   }

  // ]

]
// menudata.forEach(item => {
//   routes.push({
//     path: item.path,
//     name: item.name,
//     component: () => import('../view/' + item.component)
//   })
// });
const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

export default router
