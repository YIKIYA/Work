<template>
  <el-container>
    <el-aside width="180px">
      <comaside></comaside>
    </el-aside>
    <el-container>
      <el-header>
        <div class="Exit"><el-button @click="Exit">退出系统</el-button></div>
      </el-header>
      <el-main><router-view/></el-main>
    </el-container>
  </el-container>
</template>
<script>
import Comaside from './Comaside.vue'
export default {
  data () {
    return {

    }
  },
  methods: {
    Exit () {
      this.$router.push('/')
      location.reload()
    }
  },
  components: {
    Comaside
  }
}
</script>
<style type="text/css">
html,
body,
#app,
.el-container {
  /*设置内部填充为0，几个布局元素之间没有间距*/
  padding: 0px;
  /*外部间距也是如此设置*/
  margin: 0px;
  /*统一设置高度为100%*/
  height: 100%;
}
.el-header {
  background-color: #000000;
  color: rgb(255, 255, 255);
  text-align: center;
  line-height: 60px;
}

.el-aside {
  background-color: #ffffff;
  color: rgb(255, 247, 247);
  text-align: center;
  line-height: 100%;
}

.el-main {
  background-color: #ffffff;
  color: #333;
  text-align: center;
  line-height: 160px;
}
.Exit {
  margin-left: 90%;
}
</style>
