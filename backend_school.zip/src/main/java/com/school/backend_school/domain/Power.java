package com.school.backend_school.domain;

import lombok.Data;

/**
 * @author Lenovo
 */
@Data
public class Power {
    private int pid;
    private String pname;
    private int type;
    private String path;

    public int getPid() {
        return pid;
    }

    public void setPid(int pid) {
        this.pid = pid;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    @Override
    public String toString(){
        return  "Power{" +
                "Pid" + pid +
                ",Pname=" + pname + '\'' +
                ",Type=" + type + '\'' +
                ",Path=" + path + '\'' +
                "}";
    }
}
