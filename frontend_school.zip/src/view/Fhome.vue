<template>
  <el-table
    :data="tableData"
    style="width: 100%">
    <el-table-column
      prop="date"
      label="姓名"
      width="150">
    </el-table-column>
    <el-table-column
      prop="date"
      label="姓名"
      width="150">
    </el-table-column>
  </el-table>
</template>
<script>
export default {
  name: 'UpdateMessage'
}
</script>
<style scoped>
</style>
