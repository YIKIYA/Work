package com.school.backend_school;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.school.backend_school.mapper")
public class BackendSchoolApplication {

    public static void main(String[] args) {
        SpringApplication.run(BackendSchoolApplication.class, args);
    }

}
