<template>
  <el-container>
    <el-header>
      <img src="@/assets/head.png" width="100%" height="80px" magrin="0" />
    </el-header>
      <div class="boxwai">
        <fieldset>
          <el-card>
            <center><h2>新用户注册</h2></center>
          <el-form
            :model="ruleForm"
            status-icon
            :rules="rules"
            ref="ruleForm"
            label-width="100px"
            class="demo-ruleForm"
          >
            <el-form-item label="用户名" prop="name" required="true">
              <el-input v-model="ruleForm.name" autocomplete="open"></el-input>
            </el-form-item>
            <el-form-item label="性别" prop="sex" required="true">
              <el-input v-model="ruleForm.sex" autocomplete="open"></el-input>
            </el-form-item>
            <el-form-item label="电话号码" prop="phone" required="true">
              <el-input v-model="ruleForm.phone" autocomplete="open"></el-input>
            </el-form-item>
            <el-form-item label="邮箱" prop="email" required="true">
              <el-input v-model.number="ruleForm.email"></el-input>
            </el-form-item>
            <el-form-item label="身份证号" prop="id" required="true">
              <el-input
                v-model="ruleForm.id"
                autocomplete="open"
              ></el-input>
            </el-form-item>
            <el-form-item label="密码" prop="pass" required="true">
              <el-input
                type="password"
                v-model="ruleForm.pass"
                autocomplete="off"
              ></el-input>
            </el-form-item>
            <el-form-item>
              <center>
                <el-button type="primary" @click="submitForm"
                  >注册</el-button
                >
                <el-button @click="resetForm('ruleForm')">重置</el-button>
                <el-button @click="returnlogin('ruleForm')">返回登录</el-button>
              </center>
            </el-form-item>
          </el-form>
          <h4>填写说明:</h4>
          <h5>用户名请输入真实姓名！</h5>
          <h5>
            注册用户请如实填写，带有*表示为必填的（后面系统出现不在提醒）。
          </h5>
          <h5>注册成功后点击返回跳转到登录页面。登录名为你的用户名。</h5>
          </el-card>
        </fieldset>
      </div>
  </el-container>
</template>
<script>
import axios from 'axios'
// import util from '@/util/util'

export default {
  data () {
    var checkname = (rule, value, callback) => {
      if (!value) {
        return callback(new Error('用户名不能为空'))
      }
    }
    var checksex = (rule, value, callback) => {
      if (!value) {
        return callback(new Error('性别不能为空'))
      }
    }
    var checktele = (rule, value, callback) => {
      if (!value) {
        return callback(new Error('电话号码不能为空'))
      }
    }
    var checkid = (rule, value, callback) => {
      if (!value) {
        return callback(new Error('身份证不能为空'))
      }
    }
    var checkemail = (rule, value, callback) => {
      if (!value) {
        return callback(new Error('邮箱不能为空'))
      }
    }
    // 验证密码是否相同
    var validatePass = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入密码'))
      } else {
        callback()
      }
    }
    return {
      ruleForm: {
        userId: 1,
        name: '',
        sex: '',
        id: '',
        phone: '',
        email: '',
        pass: ''
      },
      rules: {
        name: [{ validator: checkname, trigger: 'blur' }],
        sex: [{ validator: checksex, trigger: 'blur' }],
        id: [{ validator: checkid, trigger: 'blur' }],
        phone: [{ validator: checktele, trigger: 'blur' }],
        pass: [{ validator: validatePass, trigger: 'blur' }],
        email: [{ validator: checkemail, trigger: 'blur' }]
      }
    }
  },
  created () {
    this.getUserId()
  },
  methods: {
    submitForm () {
      axios.post('/api/saveRegisterUser', this.ruleForm).then(res => {

      })
      this.$message({
        type: 'success',
        message: '成功,等待管理员审核'
      })
    },
    resetForm (formName) {
      this.$refs[formName].resetFields()
    },
    returnlogin () {
      this.$router.push('/')
    },
    getUserId () {
      axios.get('/api/registerUserId').then(res => {
        this.ruleForm.userId = res.data
      })
    }
  }
}
</script>
<style scoped>
.el-container{
  background: #555454;
}
fieldset {
  /* 表单页面居中，宽度50% ,legend颜色设置，legend圆角*/
  border: 2px solid #dcdfe6;
  text-align: left;
  border-radius: 8px;
  margin: 0 auto;
  width: 50%;
}
.boxwai {
  margin-top: 5%;
}
</style>
