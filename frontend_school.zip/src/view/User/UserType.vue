<template>
    <el-card>
    <el-header>
      <center><span>分配用户角色</span></center>
    </el-header>
    <div>
      <el-table :data="tableData" style="width: 100%">
        <el-table-column label="用户id" width="180">
          <template slot-scope="scope">
            <span style="margin-left: 10px">{{ scope.row.userId }}</span>
          </template>
        </el-table-column>
        <el-table-column label="用户姓名" width="180">
          <template slot-scope="scope">
            <span style="margin-left: 10px">{{ scope.row.name }}</span>
          </template>
        </el-table-column>
        <el-table-column label="性别" width="150">
          <template slot-scope="scope">
            <span style="margin-left: 10px">{{ scope.row.sex }}</span>
          </template>
        </el-table-column>
        <el-table-column label="身份证号" width="240">
          <template slot-scope="scope">
            <span style="margin-left: 10px">{{ scope.row.id }}</span>
          </template>
        </el-table-column>
        <el-table-column label="电话" width="180">
          <template slot-scope="scope">
            <span style="margin-left: 10px">{{ scope.row.phone }}</span>
          </template>
        </el-table-column>
        <el-table-column label="邮箱" width="180">
          <template slot-scope="scope">
            <span style="margin-left: 10px">{{ scope.row.email }}</span>
          </template>
        </el-table-column>
        <el-table-column label="分配角色" width="180">
          <template slot-scope="scope">
            <el-button size="mini" type="danger" @click="handleType(scope.row)">当前角色为：{{scope.row.type}}</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- 分页 -->
    <div class="pag">
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="limitPage.page"
        :page-sizes="[5, 10, 15, 20]"
        :page-size="limitPage.limit"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total">
      </el-pagination>
    </div>
        <!-- 弹出框 -->
    <template>
      <el-dialog
        title="分配用户角色"
        :visible.sync="centerDialogVisible"
        width="30%"
        center>
        <el-table :data="tableDataType" style="width: 100%">
          <el-table-column label="角色名" width="150">
            <template slot-scope="scope">
              <span style="margin-left: 10px">{{ scope.row.type }}</span>
            </template>
          </el-table-column>
          <el-table-column label="决定" width="200">
            <template slot-scope="scope">
              <el-button size="mini" type="success" @click="handleChangeType(scope.row.num)">选择</el-button>
            </template>
          </el-table-column>
        </el-table>
        <span slot="footer" class="dialog-footer">
          <el-button @click="centerDialogVisible = false">取 消</el-button>
        </span>
      </el-dialog>
    </template>
  </el-card>
</template>

<script>
import axios from 'axios'

export default {
  data () {
    return {
      centerDialogVisible: false,
      tableData: [

      ],
      tableDataType: [
        {
          type: '用户',
          num: 3
        },
        {
          type: '审核单位',
          num: 2
        },
        {
          type: '专家',
          num: '1'
        },
        {
          type: '管理员',
          num: 0
        }
      ],
      limitPage: {
        page: 1,
        limit: 5
      },
      total: 0,
      dataByType: {}
    }
  },
  created () {
    this.showPage()
  },
  methods: {
    // 分页
    handleSizeChange (val) {
      this.limitPage.limit = val
      this.showPage()
    },
    handleCurrentChange (val) {
      this.limitPage.page = val
      this.showPage()
    },
    showPage () {
      axios.post(`/api/findRegisterFalseByPage/${this.limitPage.page}/${this.limitPage.limit}`).then(res => {
        this.tableData = res.data
        this.count()
      })
    },
    count () {
      axios.get(`/api/registerFalseCount`).then(res => {
        this.total = res.data
      })
    },
    save () {
      axios.put(`/api/updateRegister`, this.dataByType).then(res => {

      })
      this.$message({
        type: 'success',
        message: '成功'
      })
    },
    saveUser () {
      
    },
    handleType (oneData) {
      this.dataByType = oneData
      this.centerDialogVisible = true
    },
    handleChangeType (num) {
      this.dataByType.type = num
      this.save()
      this.centerDialogVisible = false
    }
  }
}
</script>

<style>

</style>
