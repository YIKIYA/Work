<template>
  <el-container>
    <el-header>
      <img src="@/assets/head.png" width="100%" height="80px" magrin="0" />
    </el-header>
      <div class="boxwai">
        <fieldset>
          <center><h2>重置密码</h2></center>
          <el-form
            :model="ruleForm"
            status-icon
            :rules="rules"
            ref="ruleForm"
            label-width="100px"
            class="demo-ruleForm"
          >
            <el-form-item label="用户名" prop="name" required="true">
              <el-input v-model="ruleForm.name" autocomplete="open"></el-input>
            </el-form-item>
            <el-form-item label="身份证" prop="id" required="true">
              <el-input
                v-model="ruleForm.id"
                autocomplete="open"
              ></el-input>
            </el-form-item>
            <el-form-item label="新密码" prop="pass"  required="true">
              <el-input
                type="password"
                v-model="ruleForm.pass"
                autocomplete="off"
              ></el-input>
            </el-form-item>
            <el-form-item>
              <center>
                <el-button type="primary" @click="submitForm('ruleForm')"
                  >修改</el-button
                >
                <el-button @click="resetForm('ruleForm')">重置</el-button>
                <el-button @click="returnlogin('ruleForm')">返回登录</el-button>
              </center>
            </el-form-item>
          </el-form>
          <h4>填写说明:</h4>
          <h5>
            通过身份证重置密码，重置密码为123，若遗忘，请联系管理员
          </h5>
          <h5>修改成功后点击返回跳转到登录页</h5>
        </fieldset>
      </div>
  </el-container>
</template>
<script>
export default {
  data () {
    var checkname = (rule, value, callback) => {
      if (!value) {
        return callback(new Error('用户名不能为空'))
      }
    }
    var checkanwser = (rule, value, callback) => {
      if (!value) {
        return callback(new Error('id不能为空'))
      }
    }
    // 验证密码是否相同
    var validatePass = (rule, value, callback) => {
      if (value === '') {
        callback(new Error('请输入密码'))
      } else {
        if (this.ruleForm.checkPass !== '') {
          this.$refs.ruleForm.validateField('checkPass')
        }
        callback()
      }
    }
    return {
      ruleForm: {
        name: '',
        id: '',
        pass: '',
        email: ''
      },
      rules: {
        name: [{ validator: checkname, trigger: 'blur' }],
        id: [{ validator: checkanwser, trigger: 'blur' }],
        pass: [{ validator: validatePass, trigger: 'blur' }]
      }
    }
  },
  methods: {
    submitForm (formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          alert('submit!')
        } else {
          return false
        }
      })
    },
    resetForm (formName) {
      this.$refs[formName].resetFields()
    },
    returnlogin () {
      this.$router.push('/')
    }
  }
}
</script>
<style scoped>
fieldset {
  /* 表单页面居中，宽度50% ,legend颜色设置，legend圆角*/
  border: 2px solid #dcdfe6;
  text-align: left;
  border-radius: 8px;
  margin: 0 auto;
  width: 50%;
}
.boxwai {
  margin-top: 5%;
}
</style>
