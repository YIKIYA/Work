package com.school.backend_school.controller;

import com.alibaba.fastjson.JSON;
import com.school.backend_school.domain.User;
import com.school.backend_school.service.UserService;
import com.school.backend_school.utils.ActionCode;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Map;

@RestController
public class LoginController {
    @Autowired
    private UserService userService;

    //验证码
    @GetMapping("/checkCode")
    public void checkCode(HttpServletRequest request, HttpServletResponse response){
        //创建验证码对象
        ActionCode actionCode = new ActionCode();
        //生成图片
        BufferedImage image = actionCode.getImage();
        //生成文字
        String text = actionCode.getText();
        //创建session
        HttpSession session = request.getSession();
        //记录验证码
        session.setAttribute("ver_code",text);
        //发送验证码
        try {
            ActionCode.output(image,response.getOutputStream());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //登录
    @PostMapping("/userLogin")
    public boolean login(@RequestBody Map<String,String> map, HttpServletRequest request){
        //获取session
        HttpSession session = request.getSession();

        //把json转为对象
        System.out.println(map);
        User tUser = JSON.parseObject(JSON.toJSON(map).toString(), User.class);
        System.out.println(tUser.getUsername());
        System.out.println(tUser.getUserpassword());
        //判断验证码
        if (session.getAttribute("ver_code").toString().equals(tUser.getCode())) {
            //判断登录
            if (userService.login(tUser.getUsername(),tUser.getUserpassword())) {
                session.setAttribute("username",tUser);
                return true;
            }
        }
        return false;
    }
}
