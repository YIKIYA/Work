package com.school.backend_school.service.Impl;

import com.school.backend_school.domain.Power;
import com.school.backend_school.domain.User;

import java.io.PipedWriter;
import java.util.List;

public interface PowerServiceImpl {
    List<Power> findAll();

    List<Power> findByType(int type);

    int count(int type);

    void save(Power power);
}
