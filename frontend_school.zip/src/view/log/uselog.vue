<template>
  <el-card>
    <el-container>
    <!-- <div>
      <el-breadcrumb separator-class="el-icon-arrow-right">
        <el-breadcrumb-item>首页</el-breadcrumb-item>
        <el-breadcrumb-item>日志</el-breadcrumb-item>
        <el-breadcrumb-item>操作日志</el-breadcrumb-item>
      </el-breadcrumb>
    </div> -->
    <template>
    <div>
    <el-table :data="tableData" style="width: 100%">
      <el-table-column label="操作id" width="50%">
        <template slot-scope="scope">
          <span style="margin-left: 10px">{{ scope.row.id }}</span>
        </template>
      </el-table-column>
      <el-table-column label="时间" width="100%">
        <template slot-scope="scope">
          <span style="margin-left: 10px">{{ scope.row.date }}</span>
        </template>
      </el-table-column>
      <el-table-column label="请求url" width="180">
        <template slot-scope="scope">
          <span style="margin-left: 10px">{{ scope.row.url }}</span>
        </template>
      </el-table-column>
      <el-table-column label="请求类型" width="80%">
        <template slot-scope="scope">
          <span style="margin-left: 10px">{{ scope.row.httpMethod }}</span>
        </template>
      </el-table-column>
      <el-table-column label="请求ip" width="180">
        <template slot-scope="scope">
          <span style="margin-left: 10px">{{ scope.row.ip }}</span>
        </template>
      </el-table-column>
      <el-table-column label="返回结果" width="540">
        <template slot-scope="scope">
          <span style="margin-left: 10px">{{ scope.row.response }}</span>
        </template>
      </el-table-column>
      <el-table-column label="删除数据" width="80%">
        <template slot-scope="scope">
          <el-button size="mini" type="danger" @click="handleDelete(scope.row.id)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
  </template>
  </el-container>
      <!-- 分页 -->
    <div class="pag">
      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="limitPage.page"
        :page-sizes="[5, 10, 15, 20]"
        :page-size="limitPage.limit"
        layout="total, sizes, prev, pager, next, jumper"
        :total="total">
      </el-pagination>
    </div>
  </el-card>
</template>

<script>
import axios from 'axios'

export default {
  name: 'Operlog',
  data () {
    return {
      tableData: [
        {
          id: '1',
          date: '2020-01-02',
          url: 'http://locallost:8181/Login',
          httpMethod: 'GET',
          ip: '127.0.0.1',
          response: 'true'
        }
      ],
      limitPage: {
        page: 1,
        limit: 5
      },
      total: 0
    }
  },
  created () {
    this.showPage()
  },
  methods: {
    // 分页
    handleSizeChange (val) {
      this.limitPage.limit = val
      this.showPage()
    },
    handleCurrentChange (val) {
      this.limitPage.page = val
      this.showPage()
    },
    showPage () {
      axios.post(`/api/logOperationFindPage/${this.limitPage.page}/${this.limitPage.limit}`).then(res => {
        this.tableData = res.data
        this.conut()
      })
    },
    // 总数
    conut () {
      axios.get('/api/logOperationCount').then(res => {
        this.total = res.data
      })
    },
    handleDelete (id) {
      this.$confirm('是否删除', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        axios.delete(`/api/deleteLogOperationCount/${id}`).then(res => {
          this.showPage()
        })
        this.$message({
          type: 'success',
          message: '删除成功'
        })
      })
    }
  }
}
</script>

<style>
.el-table thead {
    color: #686868;
    font-weight: 500;
}
.el.card{
  margin-top: 50px;
}
.pag{
  text-align: center;
}
</style>
