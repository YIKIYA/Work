<template>
  <div>
    <el-breadcrumb separator-class="el-icon-arrow-right">
      <el-breadcrumb-item>个人中心</el-breadcrumb-item>
      <el-breadcrumb-item><a href="/Personmessage">个人信息</a></el-breadcrumb-item>
    </el-breadcrumb>
    <div>
      <el-card class="box-card">
        <span><h1>基本资料</h1></span>
        <div slot="header" class="clearfix"></div>
        <div>
          <el-form
            label-width="80px"
            v-model="dataFrom"
            size="big"
            label-position="right"
          >
            <el-form-item label="姓名" prop="name">
              <el-input auto-complete="off" v-model="dataForm.name"></el-input>
            </el-form-item>
            <el-form-item label="性别" prop="sex">
              <el-input auto-complete="off" v-model="dataForm.sex"></el-input>
            </el-form-item>
            <el-form-item label="身份证号" prop="id">
              <el-input maxlength="18" v-model="dataForm.id"></el-input>
            </el-form-item>
            <el-form-item label="手机号" prop="phone">
              <el-input maxlength="13" v-model="dataForm.phone"></el-input>
            </el-form-item>
            <el-form-item label="邮箱号" prop="email">
              <el-input auto-complete="off" v-model="dataForm.email"></el-input>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button size="small" type="primary" @click="saveMessage">提交</el-button>
          </div>
        </div>
      </el-card>
    </div>
  </div>
</template>

<script>
import Timeline from './Timeline.vue'
import axios from 'axios'
import util from '@/util/util'

export default {
  components: { Timeline },
  data () {
    return {
      dataForm: {

      }
    }
  },
  created () {
    this.show()
  },
  methods: {
    show () {
      axios.get(`/api/findRegisterByUserId/${util.userId}`).then(res => {
        this.dataForm = res.data
      })
    },
    saveMessage () {
      axios.put(`/api/updateRegister`, this.dataForm).then(res => {

      })
      this.$message({
        type: 'success',
        message: '成功'
      })
    }
  }
}
</script>

<style scoped>
.el-card {
  margin-top: 50px;
  padding-top: 20px;
  position: relative;
  width: 100%;
  height: auto;
  display: flex;
  justify-content: center;
  align-items: center;
}
</style>
