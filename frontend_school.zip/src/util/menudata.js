export default [
  {
    path: '/Fhome',
    name: 'Fhome',
    label: '首页',
    url: 'Fhome/Fhome',
    component: 'Fhome'
  },
  {
    path: '/Personmessage',
    name: 'Personmessage',
    label: '个人信息',
    url: 'Personmessage/Personmessage',
    component: 'Personmessage'
  },
  {
    path: '/Messageupdate',
    name: 'Messageupdate',
    label: '信息修改',
    url: 'Messageupdate/Messageupdate',
    component: 'Messageupdate'
  },
  {
    path: '/Doctor1',
    name: 'Doctor1',
    label: '申报资料填写',
    url: 'Doctor1/Doctor1',
    component: 'Doctor1'
  },
  {
    path: '/Timeline',
    name: 'Timeline',
    label: '审核进度',
    url: 'Timeline/Timeline',
    component: 'Timeline'
  }
]
