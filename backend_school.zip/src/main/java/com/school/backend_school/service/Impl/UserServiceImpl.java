package com.school.backend_school.service.Impl;

import com.school.backend_school.domain.User;

import java.util.List;

public interface UserServiceImpl {

    List<User> findAll();

    int count();

    void save(User user);

    void delete(int id);

    void update(User user);

    User findById(int id);

    boolean login(String username, String password);
}
