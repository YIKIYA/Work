package com.school.backend_school.mapper;

import com.school.backend_school.domain.Power;
import com.school.backend_school.domain.User;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface PowerMapper {
    @Select("Select * from power")
    List<Power> getSelect();

    @Select("select * from power where type=#{type}")
    List<Power> getSelectByType(int type);

    @Select("Select count(*) from power where type=#{type}")
    int total(int type);

    @Insert("insert into power(pid,pname,type,path) values (#{pid},#{pname},#{type},#{path})")
    void insert(Power power);
}
