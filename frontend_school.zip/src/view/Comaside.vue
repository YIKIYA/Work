<template>
  <div>
    <h3>高校职称评审系统</h3>
    <el-menu background-color="#545457" text-color="white" router :default-closeeds="['0', '1']">
      <el-submenu
        v-for="(item, index) in Menu"
        :key="index"
        :index="index + ''"
      >
        <template slot="title">{{ item.name }}</template>
        <el-menu-item-group>
          <el-menu-item
            v-for="(item2, index2) in item.Children"
            :key="index2"
            :index="item2.path"
            :class="$route.path == item2.path ? 'is-active' : ''"
            >{{ item2.name }}</el-menu-item
          >
        </el-menu-item-group>
      </el-submenu>
    </el-menu>
  </div>
</template>
<script>
import axios from 'axios'
import util from '@/util/util'

// import menudata from "@/util/menudata";
export default {
  data () {
    return {
      Menu: {

      }
    }
  },
  created () {
    axios.get(`/api/PowerInformation/${util.type}`).then(res => {
      let menu = []
      res.data.forEach(element => {
        // eslint-disable-next-line eqeqeq
        if (element.pid == -1) {
          menu.push({
            id: element.id,
            path: element.path,
            name: element.name,
            component: element.component,
            Children: []
          })
        }
      })
      res.data.forEach(element => {
        menu.forEach(array => {
          // eslint-disable-next-line eqeqeq
          if (element.pid == array.id) {
            array.Children.push({
              path: element.path,
              name: element.name,
              component: element.component
            })
          }
        })
      })
      this.Menu = menu
    })
  },
  methods: {
  //   clickMenu(item) {
  //     this.$router.push({ name: item.name });
  //   },
  // },
  // computed: {
  //   noChildren() {
  //     return this.menudata.filter((item) => !item.children);
  //   },
  //   hasChildren() {
  //     return this.menudata.filter((item) => item.children);
  //   },
  //     isCollapse() {
  //       return this.$store.state.tab.isCollapse;
  //     },
  //   },
  }
}
</script>
<style>
.el-submenu {
  background-color: #030303 !important;

  color: #080808 !important;
}
.el-aside {
  background-color: #545457;
}
</style>
