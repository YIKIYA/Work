<template>
  <div class="block">
  <div class="radio">
    <el-radio-group v-model="reverse">
      <el-radio :label="true">倒序</el-radio>
      <el-radio :label="false">正序</el-radio>
    </el-radio-group>
  </div>

  <el-timeline :reverse="reverse">
    <el-timeline-item
      v-for="(activity, index) in activities"
      :key="index"
      :timestamp="activity.timestamp">
      {{activity.content}}
    </el-timeline-item>
  </el-timeline>
</div>
</template>
<script>
export default {
  data () {
    return {
      reverse: true,
      activities: [{
        content: '完成提交',
        timestamp: '2018-04-25'
      }, {
        content: '通过二审',
        timestamp: '2018-04-23'
      },
      {
        content: '通过一审',
        timestamp: '2018-04-15'
      }, {
        content: '申报提交',
        timestamp: '2018-04-11'
      }]
    }
  }
}
</script>

