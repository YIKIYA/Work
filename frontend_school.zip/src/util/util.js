const userId = '0'
const username = '123'
const type = '3'
export default{
  userId,
  username,
  type
}
